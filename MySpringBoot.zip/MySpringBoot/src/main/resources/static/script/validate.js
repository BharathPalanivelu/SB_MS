function validateLogin(){
	
	var flag=false;
	
	var userName=f1.userName.value;
	var userPwd=f1.userPwd.value;
	
	if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="* Please enter UserName.";
	}else if(userPwd==""||userPwd==null){
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="* Please enter Password.";
	}else{
		flag=true;
	}
	
	
	
	return flag;
}