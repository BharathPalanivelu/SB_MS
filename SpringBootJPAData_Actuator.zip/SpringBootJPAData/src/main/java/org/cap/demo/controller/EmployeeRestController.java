package org.cap.demo.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.cap.demo.model.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.jdbc.DatabaseMetaData;

@RestController
@RequestMapping("/api/v2")
public class EmployeeRestController {
	
	@Autowired
	private EntityManagerFactory emf;
	
	@Autowired
	private IEmployeeService employeeService;
	
	@GetMapping("/empsalrange/{minsalary}/{maxsalary}")
	public ResponseEntity<List<Employee>> findBySalRangeOfEmployees(
			@PathVariable("minsalary")double minsalary,
			@PathVariable("maxsalary")double maxsalary){
		
		List<Employee> employees= employeeService.findBySalaryWithRange(minsalary, maxsalary);
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@GetMapping("/empsal/{salary}")
	public ResponseEntity<List<Employee>> findBySalEmployees(
			@PathVariable("salary")double salary){
		
		List<Employee> employees= employeeService.findBySalary(salary);
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(
		@RequestBody Employee employee){
		
		List<Employee> employees= employeeService.createEmployee(employee);
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	
	@GetMapping("/employees/{empId}")
	public ResponseEntity<Employee> findEmployees(
			@PathVariable("empId")Integer empId){
		
		Employee employees= employeeService.findEmployee(empId);
		if(employees==null) {
			return new ResponseEntity("Sorry! Employee ID not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<Employee>(employees, HttpStatus.OK);
	}
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() throws SQLException{
		//DatabaseMeta=emf.getDataSource().getConnection().getMetaData();
		//Map<String, Object > map=emf.getProperties();
		
			//System.out.println(map);
		
		
		
		List<Employee> employees= employeeService.getAllEmployees();
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

}
