package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
@Transactional
public interface IEmployeeDBDao extends JpaRepository<Employee, Integer> {

	
	public List<Employee> findBySalary(double salary);
	
	@Query("from Employee emp where emp.salary between :minSalary and :maxSalary")
	public List<Employee> findBySalaryWithRange(
			@Param("minSalary")double minSalary,
			@Param("maxSalary")double maxSalary);
}
