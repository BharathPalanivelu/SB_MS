package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.DispatcherServlet;

@SpringBootApplication(excludeName= {"DispatcherServlet","DataSource"})
		//exclude= {DispatcherServlet.class})
public class SpringBootJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaDataApplication.class, args);
	}

}
