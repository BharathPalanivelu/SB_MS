package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Employee;
import org.springframework.data.repository.query.Param;

public interface IEmployeeService {
	public List<Employee> getAllEmployees();

	public List<Employee> createEmployee(Employee employee);

	public Employee findEmployee(Integer empId);
	public List<Employee> findBySalary(double salary);
	public List<Employee> findBySalaryWithRange(double minSalary,double maxSalary);

}
